<?php
  $config['database']['host'] = 'localhost';
  $config['database']['user'] = 'root';
  $config['database']['pass'] = 'root';
  $config['database']['name'] = 'tubes';

  $config['url']['base_url'] = 'http://tubes.dev/';
