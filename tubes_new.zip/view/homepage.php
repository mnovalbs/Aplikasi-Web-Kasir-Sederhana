<?php
  $this->load->view('header');
  echo $num_rows;
  echo "Nama : ".$aku;

  $this->load->view('footer');
?>
