<ul id='menu-atas'>
  <li>
    <a href='<?php echo base_url('admin'); ?>'><i class='fa fa-home'></i> Dashboard</a>
  </li>
  <li>
    <a href='<?php echo base_url('admin/kategori'); ?>'><i class='fa fa-tags'></i> Kategori</a>
  </li>
  <li>
    <a href='<?php echo base_url('admin/barang'); ?>'><i class='fa fa-database'></i> Barang</a>
  </li>
  <li>
    <a href='<?php echo base_url('admin/petugas'); ?>'><i class='fa fa-users'></i> Petugas</a>
  </li>
  <li>
    <a href='<?php echo base_url('admin/logout'); ?>'><i class='fa fa-sign-out'></i> Logout</a>
  </li>
</ul>
