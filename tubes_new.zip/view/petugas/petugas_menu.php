<ul id='menu-atas' class='menu-petugas'>
  <li>
    <a href='<?php echo base_url('petugas'); ?>'><i class='fa fa-terminal'></i> Transaksi</a>
  </li>
  <li>
    <a href='<?php echo base_url('petugas/rekap'); ?>'><i class='fa fa-database'></i> Barang</a>
  </li>
  <li>
    <a href='<?php echo base_url('petugas/logout'); ?>'><i class='fa fa-sign-out'></i> Logout</a>
  </li>
</ul>
