
      </div>
      <div id='error-message'></div>
    <script src='<?php echo base_url('assets/js_jquery.js'); ?>'></script>
    <script src='<?php echo base_url('assets/js_global.js?ver='.date("Y-m-d-H:i:s")); ?>'></script>
  </body>
</html>
