<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php if(!empty($custom_title)){echo $custom_title." - ";} ?>KASIR Sederhana</title>
    <link href='<?php echo base_url('assets/font-awesome/css/font-awesome.min.css');?>' rel='stylesheet'/>
    <link href='<?php echo base_url('assets/css_style.css?ver='.date("Y-m-d-H:i:s")); ?>' rel='stylesheet'/>
  </head>
  <body>
    <div class='cd-container'>
