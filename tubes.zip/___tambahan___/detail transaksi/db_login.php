<?php
//File : db_login.php
//Deskripsi : menyimpan parameter untuk koneksi ke database

$db_host  = 'localhost';
$db_database ='tubes';
$db_username = 'root';
$db_password = '';
?>

